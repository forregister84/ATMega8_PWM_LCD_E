//***************************************************************************
//  ATMega8_PWM_2CH_LCD_E
//
//  ШИМ-генератор 1 Гц...2 МГц ((F_CPU/8))
//  Версия.........: 0.84
//  Попытка 2-х канального ШИМ
//  Длительность импульса минимум 2 такта (Phase and Frequency Correct PWM Mode)
//  Кнопка Mode - вкл/выкл выхода
//  Вывод данных на LCD индикатор
//  2 энкодера: частота и коэффициент заполнения ШИМ 
//  Шаг частоты 1/10/100/1000 Гц. Шаг ШИМ 0,01/ 0,1 / 1 / 5 %
//  Переключение кнопкой энкодера по кругу.
//  Автор..........: forregister84
//  Микроконтроллер: ATMega8
//  Компилятор.....: Atmel Studio7, AVR Studio 4.19 + avr8-gnu-toolchain-3.7.0.1796
//  Программатор...: USBasp + AVRDUDESS
//  Симуляция в Proteus 8.13 SP0
//  Дата...........: 11.09.2022
//***************************************************************************

/*
  Кварц на 16 МГц
  Фьюзы:
    CKSEL3…0=1111 (кварц на 8/16 МГц)
    CKOPT=0, (CKOPT=0, для кварца на 16 МГц, =1 для меньшей частоты)        
    SUT10=11 (Additional Delay from Reset 65 ms, Slowly rising power)
  Внутренний RC-генератор:
	CKSEL3…0=0001 - 1 МГц
	CKSEL3…0=0100 - 8 МГц
	CKOPT=1
	SUT10=10 - 65ms, Internal Calibrated RC Oscillator

  //Не зависимо от источника тактирования:
	BODEN=0 (схема супервизора питания BOD включена)
	BODLEVEL=0 (Порог BOD 4,0 В)
    WDTON=1 (Watchdog Timer is initialy disabled)
    ("0"-галочки установлены)
*/  

//PB1 - PWM1
//PB2 - PWM2

#include "main.h"

//Минимальная частота при максимальном периоде 65536 (16 бит)
//Округление до ближайшего большего
#define FREQ_MIN 1
//2*0xFFFF=0x1FFFE=131070
#define FREQ_MIN_D1 ((F_CPU+0x1FFFE*1-1)/0x1FFFE)       //123 - Делитель на 1 (fmin(16 МГц)=244,14 Гц)
#define FREQ_MIN_D8 ((F_CPU+0x1FFFE*8-1)/(0x1FFFE*8))    //16 - Делитель на 8 (30,52 Гц)
#define FREQ_MIN_D64 ((F_CPU+0x1FFFE*64-1)/(0x1FFFE*64)) // 2 - Делитель на 64 (3,81 Гц)
#define FREQ_MAX_DF1Hz ((uint16_t) sqrt(F_CPU/2)) // 2828 - Максимальная частота с дискретностью <=1 Гц
#define FREQ_MAX_DF10Hz ((uint32_t) (sqrt(F_CPU/2)*3.162278)) //8944 - Максимальная частота с дискретностью <=10 Гц
#define FREQ_MAX_DF100Hz ((uint32_t) (sqrt(F_CPU/2)*10)) // 28,284к - Максимальная частота с дискретностью <=100 Гц
#define FREQ_MAX_DF1kHz ((uint32_t) (sqrt(F_CPU/2)*31.62278)) // 89,887к - Максимальная частота с дискретностью <=1 кГц
#define FREQ_MAX_DF10kHz ((uint32_t) (sqrt(F_CPU/2)*100)) // 282,843к - Максимальная частота с дискретностью <=100 Гц

#define T_MIN (F_CPU/(2*FREQ_MAX)) //Минимальный период

//Состояние кнопок и энкодера:
//Биты переменной BTN_state:
#define BTN_st_Mode  (1<<bit0)
#define BTN_st_FreqS (1<<bit1) //Кнопка энкодера Freq
#define BTN_st_FreqM (1<<bit2) //флаг вращения влево (виртуальная кнопка)
#define BTN_st_FreqP (1<<bit3) //флаг вращения вправо
#define BTN_st_DutyS (1<<bit4) //Кнопка энкодера Duty
#define BTN_st_DutyM (1<<bit5) //флаг вращения влево
#define BTN_st_DutyP (1<<bit6) //флаг вращения вправо

//------------------------------------------------------------------------------
// Биты делителя частоты таймера 2: F_CPU/32 /64 /128 /256 /1024
#if F_CPU<1500000UL 					  //1 MHz
  #define F_T2_b2 0
  #define F_T2_b1 1
  #define F_T2_b0 1
  #define T2_TOP 30
#endif
#if (F_CPU>=1500000UL)&&(F_CPU<2500000UL) //2 MHz
  #define F_T2_b2 1
  #define F_T2_b1 0
  #define F_T2_b0 0
  #define T2_TOP 30
#endif
#if (F_CPU>=2500000UL)&&(F_CPU<4500000UL) //4 MHz
  #define F_T2_b2 1
  #define F_T2_b1 0
  #define F_T2_b0 1
  #define T2_TOP 30
#endif
#if (F_CPU>=4500000UL)&&(F_CPU<8500000UL) //8 MHz
  #define F_T2_b2 1
  #define F_T2_b1 1
  #define F_T2_b0 0
  #define T2_TOP 30
#endif
#if (F_CPU>=8500000UL) 					 //16 MHz
  #define F_T2_b2 1
  #define F_T2_b1 1
  #define F_T2_b0 1
  #define T2_TOP 14
#endif

//------------------------------------------------------------------------------
//Глобальные переменные:
char lcd_buf[21]; //буффер LCD дисплея 20x...
// char str[]="PWM Gen v0.1"; //const
uint8_t ArrayBtnState[5] = {0};

volatile uint16_t T1_TOP, T1_OCR;
volatile uint8_t  TCCR1B_tmp, TCCR1B_tmp2;

volatile uint32_t Freq;
volatile uint16_t PWM;
uint16_t T1_div; //Делитель таймера T1: 1, 8, 64, 256, 1024

// Состояние кнопок:
volatile uint8_t BTN_state, BTN_state_prev;

volatile uint16_t CNT_save_delay;//счетчик задержки на запись в EEPROM

//EEPROM:
uint32_t EEMEM E_Freq = FREQ_DEF;// Частота по умолчанию
uint16_t EEMEM E_PWM = PWM_DEF;  // ШИМ по умолчанию
//------------------------------------------------------------------------------
// Timer2 output compare interrupt service routine
//Прерывание с частотой (F_T1)/(OCR2+1)=1008,1 Гц (F_T1=31,25 кГц, OCR2+1=31)
ISR (TIMER2_COMP_vect)
{
	//SetBitVal(PORTB,1, 1); //Тест
	wdt_reset();  // Сброс сторожевого таймера
	PollEncoder();//Опрос энкодера и кнопок
	//_delay_us(100);		 //Тест
	//счетчик задержки на запись в EEPROM
	//0 - запись запрещена
	//1 - запись разрещена
	//>1 - ожидание записи
	if (CNT_save_delay > 1) CNT_save_delay--;

	//SetBitVal(PORTB,1, 0); //Тест: 4,54...7,0 мкс при 16 МГц
}

// Timer1 Overflow interrupt routine
// The Timer1 Overflow Flag (TOV1) is set each time the counter reaches TOP
// Прерывание выполняется однократно в начале периода для изменения периода и длительности ШИМ
ISR (TIMER1_OVF_vect)
{
	TCCR1B=TCCR1B_tmp; //Устанавливаем делитель Таймера 1
	//SetBitVal(PORTC,1, 1); //Тест
	//_delay_us(10);     //Задержка

	//OCIE2 - Timer2 Output Compare Match Interrupt Enable: On
	//OCIE1A - Timer1 Output Compare A Match Interrupt: Off
	// Если делитель не поменялся, то следующее прерывание не нужно:
	if (TCCR1B_tmp==TCCR1B_tmp2) TIMSK = (1<<OCIE2)|(0<<OCIE1A)|(0<<TOIE1);
	ICR1= T1_TOP; // период ШИМ (16-bit)
	OCR1A=T1_TOP-T1_OCR;
	OCR1B=T1_OCR; // длительность ШИМ (16-bit)
	//т.к. OCR1A и OCR1B обновляются в конце периода прямо перед приходом следующего прерывания
	//делитель (TCCR1B) обновляем в следующем прерывании
	TCCR1B_tmp=TCCR1B_tmp2;
	//_delay_us(10);     //Тест
	//SetBitVal(PORTC,1, 0); //Тест
}
//------------------------------------------------------------------------------
//volatile unsigned char buf[AMOUNT_NUM+2]; // размер буффера =AMOUNT_NUM+2: +точка,+конец строки
// номер элемента массива: 0...AMOUNT_NUM+1
#define buf lcd_buf
#define AMOUNT_NUM 4 // Число разрядов числа (размер буффера =AMOUNT_NUM+2: +точка,+конец строки )
//************************************************************************
// преобразует 16-bit 4-х разрядное число, записывает его в буфер индикатора       
// value - число для преобразования, comma = 0...3 - позиция точки на индикаторе(слева направо) 0...AMOUNT_NUM-1, 
//                                   comma >=    5 -  без точки  (AMOUNT_NUM+1)
// (comma = количество символов до точки)
void Uint_to_str (unsigned int value, unsigned char comma)
{
  signed char i; // номер элемента массива: 0...AMOUNT_NUM+1
  i = AMOUNT_NUM+1;
  buf[i]=0;      // конец строки
  while (i>0) {
    i--;
    if (i==comma) buf[i]='.'; // ставим точку
	else {
      buf[i] = '0'+ value%10;
      value = value/10;
	}
  }
    
}

//------------------------------------------------------------------------------
//Преобразование периода в частоту
uint32_t conv_period_freq (void)
{
	uint32_t value;
	value=(uint32_t)( (F_CPU+((uint32_t)T1_TOP*T1_div)/2 )/((uint32_t)T1_TOP*T1_div) );
	
	T1_OCR=(uint16_t)( (((uint32_t)T1_TOP)*PWM+(uint32_t)10000/2)/10000 );// Длительность импульса
	if (T1_OCR==0) T1_OCR++;	 //Если T1_OCR=0 ШИМ=0%
	//if (T1_OCR>=T1_TOP) T1_OCR=T1_TOP-1;//Если T1_OCR=T1_TOP ШИМ=100%
	if (T1_OCR>T1_TOP/2) T1_OCR=T1_TOP/2;//ШИМ > 50 % недопустим

	return value;
}

//Преобразование ton в PWM
uint16_t conv_ton_PWM (void)
{
	uint16_t value;
	value=(uint16_t)( (10000UL*((uint32_t)T1_OCR)+((uint32_t)T1_TOP)/2 )/((uint32_t)T1_TOP) );
	return value;
}

//------------------------------------------------------------------------------
//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
void T1_reg_calc (void)
{
	// Делитель таймера T1:
	T1_div=2; //F_T1= F_CPU
	TCCR1B_tmp2=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(0<<CS11)|(1<<CS10); // F_T1= F_CPU/1 (Phase and Frequency Correct PWM)
	
	if (Freq<FREQ_MIN_D1) {
		T1_div=16;
		TCCR1B_tmp2=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(1<<CS11)|(0<<CS10); // F_T1= F_CPU/8
	}
	if (Freq<FREQ_MIN_D8) {
		T1_div=128;
		TCCR1B_tmp2=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(1<<CS11)|(1<<CS10); // F_T1= F_CPU/64
	}

	if (Freq<FREQ_MIN_D64) {
		T1_div=512;
		TCCR1B_tmp2=(1<<WGM13)|(0<<WGM12)|(1<<CS12)|(0<<CS11)|(0<<CS10); // F_T1= F_CPU/256
	}

	// Расчет значений регистров Таймера 1
	T1_TOP=(uint16_t)( (F_CPU+ ((uint32_t)Freq*T1_div)/2 )/((uint32_t)Freq*T1_div) ); // Период импульса ( T=2*TOP*T1_div )
	T1_OCR=(uint16_t)( (((uint32_t)T1_TOP)*PWM+(uint32_t)10000/2)/10000 );// Длительность импульса
	if (T1_OCR==0) T1_OCR++;	 //Если T1_OCR=0 ШИМ=0%
	//if (T1_OCR==T1_TOP) T1_OCR--;//Если T1_OCR=T1_TOP ШИМ=100%
	if (T1_OCR>T1_TOP/2) T1_OCR=T1_TOP/2;//ШИМ > 50 % недопустим
	//Тест:
	// T1_TOP=1000;
	// T1_OCR=990;
	
	// Уточнение частоты:
	if (Freq>FREQ_MAX_DF1Hz) Freq=conv_period_freq();//Преобразование периода в частоту
}
//------------------------------------------------------------------------------
//функция опроса энкодера
//Проверка состояния кнопок
inline void PollEncoder(void)
{
	static unsigned char stateEncFreq; 	//хранит последовательность состояний энкодера
	static unsigned char stateEncDuty;
	unsigned char tmp;
	unsigned char currentState;
	
	uint8_t BTN_state_tmp;
	uint8_t i;
	
	//Проверка состояния кнопок
	//#define THRES (0.7*BTN_DELAY) //(threshold) - порог срабатывания
	#define THRES (BTN_DELAY) //(threshold) - порог срабатывания
	
	//Накладываем маску на состояние кнопок и энкодера
	//Cостояние вращения энкодера не трогаем т.к. биты сбрасываются в main
	BTN_state_tmp = BTN_state & (BTN_st_FreqM | BTN_st_FreqP | BTN_st_DutyM | BTN_st_DutyP);
	i=0;//1-я кнопка
	if (Button_Mode)
	{
		ArrayBtnState[i]++;
		if (ArrayBtnState[i]>THRES) ArrayBtnState[i]=THRES;
		if (ArrayBtnState[i]>=THRES) BTN_state_tmp |= BTN_st_Mode;
	}
	else
	{
		if (ArrayBtnState[i]>0) ArrayBtnState[i]--;
		if (ArrayBtnState[i]==0) BTN_state_tmp &= ~BTN_st_Mode;
	}
	
	i++;//следующяя кнопка
	if (Enc_FreqS)
	{
		ArrayBtnState[i]++;
		if (ArrayBtnState[i]>THRES) ArrayBtnState[i]=THRES;
		if (ArrayBtnState[i]>=THRES) BTN_state_tmp |= BTN_st_FreqS;
	}
	else
	{
		if (ArrayBtnState[i]>0) ArrayBtnState[i]--;
		if (ArrayBtnState[i]==0) BTN_state_tmp &= ~BTN_st_FreqS;
	}

	i++;//следующяя кнопка
	if (Enc_DutyS)
	{
		ArrayBtnState[i]++;
		if (ArrayBtnState[i]>THRES) ArrayBtnState[i]=THRES;
		if (ArrayBtnState[i]>=THRES) BTN_state_tmp |= BTN_st_DutyS;
	}
	else
	{
		if (ArrayBtnState[i]>0) ArrayBtnState[i]--;
		if (ArrayBtnState[i]==0) BTN_state_tmp &= ~BTN_st_DutyS;
	}


	//проверяем состояние выводов энкодера Freq
	currentState = 0;
	if (Enc_FreqA) {SetBit(currentState,0);}
	if (Enc_FreqB) {SetBit(currentState,1);}

	//если равно предыдущему, то выходим
	tmp = stateEncFreq;
	if (currentState != (tmp & 0b00000011))
	{
		//если не равно, то сдвигаем и сохраняем в озу
		tmp = (tmp<<2)|currentState;
		//сравниваем получившуюся последовательность
		if		(tmp == 0b11100001) BTN_state_tmp |= BTN_st_FreqP;
		else if (tmp == 0b11010010) BTN_state_tmp |= BTN_st_FreqM;
		stateEncFreq = tmp;
	}
	
	//проверяем состояние выводов энкодера Duty
	currentState = 0;
	if (Enc_DutyA) {SetBit(currentState,0);}
	if (Enc_DutyB) {SetBit(currentState,1);}

	//если равно предыдущему, то выходим
	tmp = stateEncDuty;
	if (currentState != (tmp & 0b00000011))
	{
		//если не равно, то сдвигаем и сохраняем в озу
		tmp = (tmp<<2)|currentState;
		//сравниваем получившуюся последовательность
		if		(tmp == 0b11100001)	BTN_state_tmp |= BTN_st_DutyP;
		else if (tmp == 0b11010010) BTN_state_tmp |= BTN_st_DutyM;
		stateEncDuty = tmp;
	}

	BTN_state = BTN_state_tmp;
}
//------------------------------------------------------------------------------

//void main(void) __attribute__((noreturn));
void main(void) __attribute__((OS_main));
void main(void)
{
	//Локальные переменные:
	//char *str_ptr;
	unsigned char i,mode,diapazon;
	uint32_t indication;
	uint8_t Output_Enable;
	uint8_t F_step_sel, D_step_sel;
	uint16_t step, dFreq, Freq_tmp, F_CPU_tmp;
	//-------------------------------------------------------------
	// Port B initialization
	// Выключаем подтяжку на цифровых входах
	PORTB=(0<<b5)|(0<<b4)|(0<<b3)|(0<<b2)|(0<<b1)|(0<<b0);
	DDRB= (1<<b5)|(1<<b4)|(1<<b3)|(1<<b2)|(1<<b1)|(0<<b0);//Выходы-"1", Входы-"0"

	// Port C initialization
	// Выключаем подтяжку на цифровых входах 0...5
	// PORTC.6 - RESET
	// PORTC.0-3 : ADC0-3
	// PORTC.4 - I2C SDA
	// PORTC.5 - I2C SCL
	//PORTC=(1<<b6)|(1<<b5)|(1<<b4)|(1<<b3)|(1<<b2)|(1<<b1)|(1<<b0);
	PORTC=(1<<b6) ;//0...5 - без подтяжки
	DDRC=        (0<<b5)|(0<<b4)|(0<<b3)|(0<<b2)|(0<<b1)|(0<<b0);//Все входы (Выходы-"1", Входы-"0")

	// Port D initialization
	PORTD=(0<<b7)|(0<<b6)|(0<<b5)|(0<<b4)|(0<<b3)|(0<<b2)|(0<<b1)|(0<<b0);
	DDRD= (1<<b7)|(1<<b6)|(1<<b5)|(1<<b4)|(1<<b3)|(1<<b2)|(1<<b1)|(1<<b0);//Все выходы

	// Timer/Counter 0 initialization

	// 16 bit Timer/Counter 1 initialization
	// Clock source: System Clock,
	// Prescaler for Timer/Counter1: stop  /1  /8  /64  /256 /1024
	// Mode: Fast PWM, TOP=ICR1
	// OC1A output: Disconnected (COM1A1, COM1A0)
	// OC1B output: Disconnected (COM1B1, COM1B0)
	// Timer1 Input Capture Interrupt (TICIE1): Off
	// Timer1 Output Compare A Match Interrupt (OCIE1A): Off
	// Timer1 Output Compare B Match Interrupt (OCIE1B): Off
	// Timer1 Overflow Interrupt (TOIE1): Off
	//No clock source. (Timer/Counter stopped) CS12, CS11, CS10
	TCCR1A=(0<<COM1A1)|(0<<COM1A0)|(0<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	TCCR1B=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(0<<CS11)|(0<<CS10);
	
	//TCNT1=0x0000; //обнуляем 16-bit счетный регистр таймера/счетчика Т1
	// ICR1=(uint16_t)( F_CPU/((uint32_t)FREQ_DEF) )-1; // Период импульса - 1
	// OCR1B=(uint16_t)( F_CPU*(uint32_t)PWM_DEF/((uint32_t)FREQ_DEF*10000) )-1;// Длительность импульса - 1
	//SFIOR=(1<<PSR10);//Сброс предделителя таймера 0 и таймера 1

	// 8 bit Timer/Counter 2 initialization
	// Clock source: System Clock, 
	// Prescaler for Timer/Counter2: stop  /1  /8 /32 /64 /128 /256 /1024
	//          bits CS22,CS21,CS20:  000 001 010 011 100  101  110  111
	// Clock value: F_CPU/32=31,25 kHz, F_CPU		1   2    4    8   16 MHz
	// Mode: Clear Timer on Compare Match (CTC), TOP=OCR2
	// OC2 output: Disconnected
	//ASSR=0x00;
	TCCR2=(1<<WGM21)|(0<<WGM20)|(0<<COM21)|(0<<COM20)|(F_T2_b2<<CS22)|(F_T2_b1<<CS21)|(F_T2_b0<<CS20);
	//TCNT2=0x00;
	OCR2=T2_TOP; //Timer2 Output Compare Register (Period_T2=OCR2+1)

	// Timer(s)/Counter(s) Interrupt(s) initialization
    //OCIE2 - Timer2 Output Compare Match Interrupt: On
	//OCIE1A - Timer1 Output Compare A Match Interrupt: Off
	//TOIE1 - Timer/Counter1, Overflow Interrupt: Off
	TIMSK = (1<<OCIE2)|(0<<OCIE1A)|(0<<TOIE1); 

	// External Interrupt(s) initialization
	// INT0: Off
	// INT1: Off
	//MCUCR=0x00;

	// USART initialization
	// USART disabled
	//UCSRB=0x00;

	// Analog Comparator initialization
	// Analog Comparator: Off
	// Analog Comparator Input Capture by Timer/Counter 1: Off
	//ACSR=0x80;
	//SFIOR=0x00;

	// ADC initialization
	// ADC Free running mode disabled (однократный режим)
	// ADC Prescaler                             /2  /4  /8 /16 /32 /64 /128
	// ADC Prescaler Selections       ADPS[2:0] 001,010,011,100,101,110, 111
	// ADC Clock frequency: F_ADC=125 kHz, F_CPU          1   2   4   8   16 MHz
	// Internal 2.56V reference, cap. on AREF. Правое выравнивание результата

	// SPI initialization
	// SPI disabled
	//SPCR=0x00;
		
	// TWI initialization
	// TWI disabled
	//TWCR=0x00;

	LCD_Init(); // Инициализация портов и ЖК индикатора
	//Значения по умолчанию:
	mode=0;
	Output_Enable=1;
	BTN_state_prev=0;

	//Чтение из EEPROM
	Freq = eeprom_read_dword (&E_Freq);
	PWM = eeprom_read_word (&E_PWM);
	if ((Freq<FREQ_MIN)||(Freq>FREQ_MAX)) Freq=FREQ_DEF;
	if (PWM>PWM_MAX) PWM=PWM_DEF;
	//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
	T1_reg_calc();
	TCCR1B_tmp=TCCR1B_tmp2;
	
	ICR1= T1_TOP; // период ШИМ (16-bit)
	OCR1A=T1_TOP-T1_OCR; // длительность ШИМ1 (16-bit)
	OCR1B=T1_OCR; // длительность ШИМ2 (16-bit)
	TCNT1=0x0000; //обнуляем 16-bit счетный регистр таймера Т1
	SFIOR=(1<<PSR10);//Сброс предделителя таймера 0 и таймера 1
	// Mode: Fast PWM, TOP=ICR1
	// OC1A output: Disconnected (COM1A1, COM1A0)
	// OC1B output: Clear OC1B on Compare Match, set OC1B at BOTTOM (non-inverting mode) (COM1B1, COM1B0)
	TCCR1A=(1<<COM1A1)|(1<<COM1A0)|(1<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	TCCR1B=TCCR1B_tmp; //Устанавливаем делитель Таймера 1 (запускаем таймер)
		
	wdt_enable(WDTO_500MS); // Разрешение работы сторожевого таймера с тайм-аутом 500 мс
	asm volatile( "sei" ::);// Разрешение прерываний
	
	F_step_sel = 0;  //шаг 1 Гц
	D_step_sel = 2; //шаг 1 %
	//счетчик задержки на запись в EEPROM
	//0 - запись запрещена
	//1 - запись разрещена
	//>1 - ожидание записи 
	CNT_save_delay = 0;
  while (1){			
	//---------------------------------------------------------------------------------------------
	// SetBitVal(PORTB,1, 1); //Тест
	//Вывод на LCD - около 10 мс
	//формат вывода частоты:
	//01234567
	//    999
	//  1.000k
	// 10.000k
	//999.999k
	//1.60000M
	LCD_Goto(0, 0); // Переводим курсор на первый символ первой строки

	indication=conv_period_freq(); //Уточнение частоты  
	diapazon='k';//Килогерцы      
	if (indication<1000) 
	{
		// indication=indication*1000; //Тысячные доли герца не реализованы
		diapazon=' ';//Герцы
	} else if (indication>=1000000)
	{
		indication=(indication+5)/10; //деление с округлением
		diapazon='M';//Мегагерцы
	} 
	
	i=6;//Последний символ числа
	lcd_buf[i--]='0'+indication%10;// 0x30 - код символа '0'
	indication=indication/10;
	lcd_buf[i--]='0'+indication%10;
	indication=indication/10;
	lcd_buf[i--]='0'+indication%10;
	if (diapazon==' ') 
	{
		lcd_buf[i--]=' ';
		lcd_buf[i--]=' ';
		lcd_buf[i--]=' ';
		lcd_buf[i--]=' ';
	}
	else
	{
		if (diapazon=='k') lcd_buf[i--]='.';
		indication=indication/10;
		lcd_buf[i--]='0'+indication%10;
		indication=indication/10;             
		lcd_buf[i--]='0'+indication%10;
		indication=indication/10;
		if (diapazon=='M') lcd_buf[i--]='.';
		lcd_buf[i]='0'+indication%10; 
	}
	//Отбрасываем 1..2 ведущих нуля
	if (diapazon==' ') i=4;
	if (lcd_buf[i]=='0')
	{
		lcd_buf[i++]=' ';
		if (lcd_buf[i]=='0') lcd_buf[i++]=' ';
	}	
	lcd_buf[7]=diapazon;
	lcd_buf[8]='H';
	lcd_buf[9]='z';
	lcd_buf[10]=0; //конец строки LCD WH1602
	//lcd_buf[8]=0; //конец строки LCD WH0802
	LCD_SendString(lcd_buf);   // Выводим на дисплей LCD

	LCD_Goto(0, 1); // Переводим курсор на первый символ второй строки
	
	//conv_ton_PWM() - Уточнение коэффициента заполнения
	if (Output_Enable==1)
	{
		Uint_to_str (conv_ton_PWM(),2); // Преобразование числа в строку
	}
	else Uint_to_str (0,2); //Если выход выкл. то выводим 0 %
	
	lcd_buf[5]=' ';
	lcd_buf[6]='%';
	lcd_buf[7]=0; //конец строки
	LCD_SendString(lcd_buf);   // Выводим на дисплей LCD
	
	// SetBitVal(PORTB,1, 0); //Тест
	//---------------------------------------------------------------------------------------------
	//Дискретность частоты dFreq , Гц
	if (Freq<0xFFFF) dFreq=(uint16_t)((Freq*Freq)/F_CPU);
	else
	//Защита от переполнения 32-bit:
	{
		Freq_tmp=(uint16_t)(Freq/64);
		F_CPU_tmp=(uint16_t)(F_CPU/(64*64));
		dFreq=(uint16_t)((Freq_tmp*Freq_tmp)/F_CPU_tmp);
	}
		
	//step=1; // Шаг
	//F_step_sel - выбор шага частоты 1/10/100/1000 Гц
	if (F_step_sel == 0) step=1;
	if (F_step_sel == 1) step=10;
	if (F_step_sel == 2) step=100;
	if (F_step_sel == 3) step=1000;

	// Кнопка Freq-
	if (BTN_state== BTN_st_FreqM)
	{
		//Если текущий шаг невозможен изменяем период на 1 такт CPU
		if (dFreq>step)
		{
			//На низких частотах сюда не попадаем, поэтому делитель Timer1 не изменяем
			//Ограничение на максимальный период
			if (T1_TOP<0xFFFF) T1_TOP++;
			Freq=conv_period_freq();//Преобразование периода в частоту
		}
		else
		{
			if (Freq>(FREQ_MIN+step)) Freq-=step;
			else Freq=FREQ_MIN;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
	}

	// Кнопка Freq+
	if (BTN_state== BTN_st_FreqP)
	{
		//Если текущий шаг невозможен изменяем период на 1 такт CPU
		if (dFreq>step)
		{
			//Ограничение на минимальный период
			if (T1_TOP>T_MIN) T1_TOP--;
			Freq=conv_period_freq();//Преобразование периода в частоту
		}
		else
		{
			Freq+=step;
			if (Freq>FREQ_MAX) Freq=FREQ_MAX;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
	}
	//--------------------------------------------------------------------
	//step=1; // Шаг
	//D_step_sel - выбор шага ШИМ 0,01/ 0,1 / 1 / 5 %
	if (D_step_sel == 0) step=1;
	if (D_step_sel == 1) step=10;
	if (D_step_sel == 2) step=100;
	if (D_step_sel == 3) step=500;

	// Кнопка Duty-
	if (BTN_state== BTN_st_DutyM)
	{
		//Если шаг больше 1 такта
		if ( ((((uint32_t)T1_TOP)*step)/10000) > 1)
		{
			if (PWM>(PWM_MIN+step)) PWM-=step;
			else PWM=PWM_MIN;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
		else if (T1_OCR>1)
		{
			T1_OCR--;
			PWM= conv_ton_PWM();//Преобразование ton в PWM (коэффициент заполнения)
		}
	}

	// Кнопка Duty+
	if (BTN_state== BTN_st_DutyP)
	{
		//Если шаг больше 1 такта
		if ( ((((uint32_t)T1_TOP)*step)/10000) > 1)
		{
			PWM+=step;
			if (PWM>PWM_MAX) PWM=PWM_MAX;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
		//ШИМ > 50 % недопустим
		else if (T1_OCR<T1_TOP/2)
		{
			T1_OCR++;
			PWM= conv_ton_PWM();//Преобразование ton в PWM (коэффициент заполнения)
		}
	}
	
	//--------------------------------------------------------------------
	//Кнопка энкодера Freq
	//F_step_sel - выбор шага частоты 1/10/100/1000 Гц
	if ((BTN_state == BTN_st_FreqS) && (BTN_state_prev != BTN_state))
	{
		F_step_sel++;
		if (F_step_sel > 3) F_step_sel = 0;
	}

	//--------------------------------------------------------------------
	//Кнопка энкодера Duty
	//D_step_sel - выбор шага ШИМ 0,01/ 0,1 / 1 / 5 %
	if ((BTN_state == BTN_st_DutyS) && (BTN_state_prev != BTN_state))
	{
		D_step_sel++;
		if (D_step_sel > 3)
		{
			D_step_sel = 0;
			if (T1_TOP<999) D_step_sel = 1;//Если период меньше 1000 тактов, то дискретность ШИМ больше 0,1%
			if (T1_TOP< 99) D_step_sel = 2;//Если период меньше 100 тактов, то дискретность ШИМ больше 1%
		}
	}

	//--------------------------------------------------------------------
	// Кнопка Mode.					
	if ((BTN_state == BTN_st_Mode) && (BTN_state_prev != BTN_state)) 
	{
		mode++; 
		if (mode>1) mode=0;
		if (mode==0) Output_Enable=1; else Output_Enable=0;
	}
	//--------------------------------------------------------------------
	BTN_state_prev=BTN_state;//Сохраняем предыдущие состояния кнопок
	//--------------------------------------------------------------------
	//Вкл/выкл выхода
	if (Output_Enable==1)
	{
		// OC1B output: Clear OC1B on Compare Match, set OC1B at BOTTOM (non-inverting mode) (COM1B1, COM1B0)
		TCCR1A=(1<<COM1A1)|(1<<COM1A0)|(1<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	}
	else
	{
		// OC1B output: Disconnected (COM1B1=0, COM1B0=0)
		TCCR1A=(0<<COM1A1)|(0<<COM1A0)|(0<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	}
	//--------------------------------------------------------------------
	//Если нажата любая кнопка, кроме Mode
	if ((BTN_state != 0)&&(BTN_state != BTN_st_Mode))
	{
		//Сбрасываем флаги нажатия виртуальных кнопок энкодера
		BTN_state &= ~(BTN_st_FreqM | BTN_st_FreqP | BTN_st_DutyM | BTN_st_DutyP);
		
		// Обновление параметров таймера T1
		TIFR=(1<<TOV1); //Очищаем флаг предыдущего не выполненного прерывания (т.к. они были запрещены) 
						//для синхронизации с началом периода
		//OCF1A - Timer1, Output Compare A Match Flag
		//TOV1 - Timer/Counter1, Overflow Flag
		
		// Выполнение прерывания TOIE1 (1 раз и 2 раза если делитель изменился)
		//OCIE2 - Timer2 Output Compare Match Interrupt : On
		//OCIE1A - Timer1 Output Compare A Match Interrupt: Off
		//TOIE1 - Timer/Counter1, Overflow Interrupt: On
		TIMSK = (1<<OCIE2)|(0<<OCIE1A)|(1<<TOIE1); 
		CNT_save_delay = SAVE_DELAY; //перезапуск таймера записи в EEPROM
	}
	//Ожидание разрешения на запись в EEPROM
	if (CNT_save_delay == 1)
	{
		CNT_save_delay = 0; //сбрасываем флаг разрешения
		eeprom_update_dword ((uint32_t*)&E_Freq, Freq);
		eeprom_update_word ((uint16_t*)&E_PWM, PWM);
	}
	//Дополнительная задержка при удержании кнопки, чтобы цифры не мельтешили
	if (BTN_state != 0) _delay_ms (300);
 }// while (1)

} // main
