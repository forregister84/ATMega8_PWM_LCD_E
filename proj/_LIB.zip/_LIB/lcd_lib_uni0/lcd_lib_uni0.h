//***************************************************************************
//  File........: lcd_lib_uni1.h
//
//  Author(s)...: Pashgan    chipenable.ru
//
//  Target(s)...: ATMega...
//
//  Compiler....: Atmel Studio7, AVR Studio 4.19 + AVR Toolchain 3.7.0.1796
//
//  Description.: Драйвер знакосинтезирующего ЖК индикатора, режим 4 бит
//
//  Data........: 28.10.09  
//
//***************************************************************************

//RS,E, D4-D7 должны быть подключены к одному порту
//в произвольном порядке
//Вывод RW индикатора подключен к земле и к контроллеру не подключается

#ifndef LCD_LIB_H
#define LCD_LIB_H

#include "main.h"
#include <util/delay.h>
#include <avr/pgmspace.h>

//порт к которому подключены управляющие выводы и шина данных ЖКИ
#define PORT_LCD PORTD
#define DDRX_LCD DDRD

//Номера выводов к которым подключены управляющие выводы ЖКИ 
#define RS 0
#define EN 2

//Номера выводов к которым подключена шина данных ЖКИ
//#define D4 4
//#define D5 5
//#define D6 6
//#define D7 7

//#define F_CPU 16000000

#define HD44780

//******************************************************************************
//макросы

/*позиционирование курсора*/
#define LCD_Goto(x,y) LCD_WriteCom(((((y)& 1)*0x40)+((x)& 15))|128) 


//прототипы функций
void LCD_Init(void);//инициализация портов и ЖКИ
void LCD_Clear(void);//очистка ЖКИ
void LCD_SendChar(unsigned char data); //выводит байт данных на ЖКИ
void LCD_WriteCom(unsigned char data); //посылает команду ЖКИ
//void LCD_SendStringFlash(char *str PROGMEM); //выводит строку из флэш памяти
void LCD_SendString(char *str); //выводит строку из ОЗУ

#endif //LCD_LIB_H
