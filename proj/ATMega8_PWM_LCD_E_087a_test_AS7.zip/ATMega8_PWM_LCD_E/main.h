#ifndef MAIN_H_
#define MAIN_H_
//------------------------------------------------------------------------------
#define F_CPU 1000000UL  //1 MHz (1 такт 1 мкс)
//#define F_CPU 16000000UL  //16 MHz (1 такт 62,5 нс)
//Меню: Project > Properties > Toolchain > AVR/GNU C Compiler > Symbols: F_CPU=1000000UL
//------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>  // Библиотека для работы со сторожевым таймером
#include <avr/eeprom.h>
#include <util/delay.h>
//#include <stdio.h> //printf

#include "bits_macros.h"
#include "lcd_lib_uni1.h" // Alphanumeric LCD Module functions

//------------------------------------------------------------------------------
//#define FREQ_DEF 160000 // Частота по умолчанию
#define FREQ_DEF 1300 // Частота по умолчанию


#define FREQ_MAX (F_CPU/4)
//#define FREQ_MAX 100000UL //100 кГц
//#define FREQ_MAX 65535UL //0xFFFF

#define PWM_DEF 5000 // ШИМ по умолчанию = 50 %
#define PWM_MIN 1    //00,01%
#define PWM_MAX 9999 //99,99%
//#define PWM_MAX 10000 //100%

//#define PWM_MIN 100  //1%
//#define PWM_MAX 9900 //99% (Dead time 1%)

//Задержка записи после нажатия на кнопку (чтобы не записывать слишком часто)
#define SAVE_DELAY 1291 //(1291-1)*1,55 = 2000 мс 
//#define SAVE_DELAY 10

//Количество полупериодов миганий символа LCD
#define SYM_BLINK_CYCLES 6 //6 x (100 x 1,55 мс)
//Период мигания символа LCD
#define SYM_BLINK_PERIOD 100 //100 x 1,55 мс

// Кнопки:
//PB0 - MODE (было PC5)
//PC4 - FREQ-
//PC3 - FREQ+
//PC1 - DUTY-
//PC0 - DUTY+

#define BTN_DELAY 129 //Задержка 0.775*129=100 мс на антидребезг кнопок, для симуляции сделать 30...100 мс
// #define BTN_DELAY 30
#define Button_Mode  BitIsClear(PINB,0) //Кнопка Mode.

#define Enc_FreqS BitIsClear(PINC,5) //Кнопка энкодера Freq
#define Enc_FreqA BitIsSet(PINC,4) //Freq вывод A
#define Enc_FreqB BitIsSet(PINC,3) //Freq вывод B
#define Enc_DutyS BitIsClear(PINC,2) //Кнопка энкодера Duty
#define Enc_DutyA BitIsSet(PINC,1) //Duty(PWM) вывод A
#define Enc_DutyB BitIsSet(PINC,0) //Duty(PWM) вывод B

//------------------------------------------------------------------------------
// Timer1 Compare Match A interrupt routine
//ISR (TIMER1_COMPA_vect,ISR_NAKED);

// Timer1 Overflow interrupt routine
//ISR (TIMER1_OVF_vect,ISR_NAKED);
//------------------------------------------------------------------------------
// преобразует 16-bit 4-х разрядное число, записывает его в буфер индикатора
// value - число для преобразования, comma = 0...3 - позиция точки на индикаторе(слева направо) 0...AMOUNT_NUM-1,
//                                   comma >=    5 -  без точки  (AMOUNT_NUM+1)
// (comma = количество символов до точки)
void Uint_to_str (unsigned int value, unsigned char comma);

//Проверка Dead time
void DT_check (void);

//Преобразование периода в частоту
uint32_t conv_period_freq (void);

//Преобразование ton в PWM Duty (коэффициент заполнения)
uint16_t conv_ton_PWM (void);

//Расчет регистров 16-bit таймера 1 на основе частоты и коэффициента заполнения ШИМ
void T1_reg_calc (void);

//функция опроса энкодера
//Проверка состояния кнопок
void PollEncoder(void);

//Реакция на кнопки и энкодер
void button_work(void) __attribute__((always_inline));

//Задержка 35 тактов
void delay35T (void) __attribute__((always_inline));
//------------------------------------------------------------------------------
#endif /* MAIN_H_ */