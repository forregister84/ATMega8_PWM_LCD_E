//***************************************************************************
//  ATMega8_PWM_2CH_LCD_E
//
//  ШИМ-генератор 1 Гц...2,667 МГц ((F_CPU/6))
//  Версия.........: 0.86a
//  Попытка 2-х канального ШИМ
//  Длительность импульса минимум 2 такта (Phase and Frequency Correct PWM Mode)
//  Кнопка Mode - вкл/выкл выхода
//  Вывод данных на LCD индикатор 8х2 WH0802A или 16х2 WH1602A
//  2 энкодера: частота и коэффициент заполнения ШИМ 
//  Опрос энкодеров с частотой 1,29 кГц (1,55/2) мс
//  Шаг частоты 1/10/100/1000 Гц. Шаг ШИМ 0,01/ 0,1 / 1 / 5 %
//  Переключение кнопкой энкодера по кругу.
//  Автор..........: forregister84
//  Микроконтроллер: ATMega8
//  Компилятор.....: Atmel Studio7, AVR Studio 4.19 + avr8-gnu-toolchain-3.7.0.1796
//  Программатор...: USBasp + AVRDUDESS
//  Симуляция в Proteus 8.13 SP0
//  Дата...........: 23.09.2022
//***************************************************************************

/*
  Кварц на 16 МГц
  Фьюзы:
    CKSEL3…0=1111 (кварц на 8/16 МГц)
    CKOPT=0, (CKOPT=0, для кварца на 16 МГц, =1 для меньшей частоты)        
    SUT10=11 (Additional Delay from Reset 65 ms, Slowly rising power)
  Внутренний RC-генератор:
	CKSEL3…0=0001 - 1 МГц
	CKSEL3…0=0100 - 8 МГц
	CKOPT=1
	SUT10=10 - 65ms, Internal Calibrated RC Oscillator

  //Не зависимо от источника тактирования:
	BODEN=0 (схема супервизора питания BOD включена)
	BODLEVEL=0 (Порог BOD 4,0 В)
    WDTON=1 (Watchdog Timer is initialy disabled)
    ("0"-галочки установлены)
*/  

//PB1 - PWM1
//PB2 - PWM2

#include "main.h"

//Минимальная частота при максимальном периоде 65536 (16 бит)
//Округление до ближайшего большего
#define FREQ_MIN 1
#define FREQ_MIN_D1 ((F_CPU/2+0x10000*1-1)/0x10000)       //123 - Делитель на 1 (fmin(16 МГц)=(244,14 Гц)/2 )
#define FREQ_MIN_D8 ((F_CPU/2+0x10000*8-1)/(0x10000*8))    //16 - Делитель на 8 (30,52 Гц)/2
#define FREQ_MIN_D64 ((F_CPU/2+0x10000*64-1)/(0x10000*64)) // 2 - Делитель на 64 (3,81 Гц)/2
#define FREQ_MAX_DF1Hz ((uint16_t) sqrt(F_CPU/2)) // 2828 - Максимальная частота с дискретностью <=1 Гц
#define FREQ_MAX_DF10Hz ((uint32_t) (sqrt(F_CPU/2)*3.162278)) //8944 - Максимальная частота с дискретностью <=10 Гц
#define FREQ_MAX_DF100Hz ((uint32_t) (sqrt(F_CPU/2)*10)) // 28,284к - Максимальная частота с дискретностью <=100 Гц
#define FREQ_MAX_DF1kHz ((uint32_t) (sqrt(F_CPU/2)*31.62278)) // 89,887к - Максимальная частота с дискретностью <=1 кГц
#define FREQ_MAX_DF10kHz ((uint32_t) (sqrt(F_CPU/2)*100)) // 282,843к - Максимальная частота с дискретностью <=100 Гц

#define T_MIN (F_CPU/(2*FREQ_MAX)) //Минимальный период

#define F_CPU_tmp ((uint16_t)(F_CPU/(2*64*64)))

//Состояние кнопок и энкодера:
//Биты переменной BTN_state:
#define BTN_st_Mode  (1<<bit0)
#define BTN_st_FreqS (1<<bit1) //Кнопка энкодера Freq
#define BTN_st_FreqM (1<<bit2) //флаг вращения влево (виртуальная кнопка)
#define BTN_st_FreqP (1<<bit3) //флаг вращения вправо
#define BTN_st_DutyS (1<<bit4) //Кнопка энкодера Duty
#define BTN_st_DutyM (1<<bit5) //флаг вращения влево
#define BTN_st_DutyP (1<<bit6) //флаг вращения вправо

//------------------------------------------------------------------------------
//Глобальные переменные:
char lcd_buf[16+1]; //буффер LCD дисплея 16x..
// char str[]="PWM Gen v0.1"; //const
uint8_t ArrayBtnState[5] = {0};

register uint16_t T1_TOP  asm("r10");
register uint16_t T1_OCR1 asm("r12");
register uint16_t T1_OCR2 asm("r14");
register uint8_t TCCR1B_tmp asm("r2");
uint8_t Output_Enable;

volatile uint32_t Freq;
volatile uint16_t PWM;
uint16_t T1_div; //Делитель таймера T1: 1, 8, 64, 256, 1024

// Состояние кнопок:
volatile uint8_t BTN_state, BTN_state_prev;

uint8_t mode;
uint8_t F_step_sel, D_step_sel;

uint8_t no_action_delay;

uint8_t blink_Duty; //=0 мигает частота Freq, =1 мигает коэф. заполнения Duty
uint8_t blink_cycles;
uint8_t blink_period;

volatile uint16_t save_delay;//счетчик задержки на запись в EEPROM

//EEPROM:
uint32_t EEMEM E_Freq = FREQ_DEF;// Частота по умолчанию
uint16_t EEMEM E_PWM = PWM_DEF;  // ШИМ по умолчанию

//------------------------------------------------------------------------------
// Timer1 Capture Event interrupt routine (__vector_5)
// Прерывание выполняется однократно в начале периода для обновления OCR1A, OCR1B
// Вход в прерывание 4+3=7 тактов
// 7+15=22 тактов
ISR (TIMER1_CAPT_vect,ISR_NAKED)
{
	asm volatile(
	/*Обновляем регистры OCR1A, OCR1B*/
	"out	0x2b, r13"		"\n" /*0x2B - OCR1AH, r13 - T1_OCR1_H*/
	"out	0x2a, r12"		"\n" /*0x2A - OCR1AL, r12 - T1_OCR1_L*/
	"out	0x29, r15"		"\n" /*0x29 - OCR1BH, r15 - T1_OCR2_H*/
	"out	0x28, r14"		"\n" /*0x28 - OCR1BL, r14 - T1_OCR2_L*/
/*
	"sbi	0x12, 1"		"\n" / *PORTD.1 = 1 (тест) 0x12 - PORTD * /
	"cbi	0x12, 1"		"\n" / *PORTD.1 = 0 (тест) 0x12 - PORTD * /
*/
	/*сохраняем r24*/
	"push   r24"            "\n" /*2 такта*/
	/*сохраняем SREG*/
	/*"in     r24, __SREG__"  "\n"*/
	/*"push   r24"            "\n"*/ /*2 такта*/
	/*TIMSK = (0<<TICIE1)|(1<<TOIE1);*/
	"ldi	r24, 0x04"		"\n"
	"out	0x39, r24"		"\n" /*0x39 - TIMSK*/
	/*TIFR=(0<<ICF1)|(1<<TOV1);*/ /*ICF1 очищается сам после reti*/
	/*"ldi	r24, 0x24"		"\n"*/
	"out	0x38, r24"		"\n" /*0x38 - TIFR*/

	/*восстанавливаем SREG*/
	/*"pop    r24"            "\n"*/ /*2 такта*/
	/*"out    __SREG__,r24"   "\n"*/
	"pop    r24"            "\n" /*восстанавливаем r24*/ /*2 такта*/
	"reti"                  "\n" /*4 такта*/
	: /*Список выходных операндов*/
	: /*Список входных операндов*/
	);
}


// Timer1 Overflow interrupt routine (__vector_8)
// The Timer1 Overflow Flag (TOV1) is set each time the counter reaches TOP
// Прерывание выполняется однократно в начале периода:
// Обновление делителя Таймера 1
// Обновление ICR1 (TOP)
// Вход в прерывание 4+3=7 тактов
ISR (TIMER1_OVF_vect,ISR_NAKED)
{
	asm volatile(
	/*TCCR1B=TCCR1B_tmp; //Устанавливаем делитель Таймера 1*/
	"out	0x2e, r2"		"\n" /*0x2E - TCCR1B, r2 - TCCR1B_tmp*/
	"out	0x27, r11"		"\n" /*0x27 - ICR1H, r11 - T1_TOP_H*/
	"out	0x26, r10"		"\n" /*0x26 - ICR1L, r10 - T1_TOP_L*/
/*
	"sbi	0x12, 1"		"\n" / *PORTD.1 = 1 (тест) 0x12 - PORTD * /
	"cbi	0x12, 1"		"\n" / *PORTD.1 = 0 (тест) 0x12 - PORTD * /
*/
	/*сохраняем r24*/
	"push   r24"            "\n" /*2 такта*/
	/*сохраняем SREG*/
	/*"in     r24, __SREG__"  "\n"*/
	/*"push   r24"            "\n"*/
	/*TIMSK = (0<<TICIE1)|(0<<TOIE1);*/
	"ldi	r24, 0x00"		"\n"
	"out	0x39, r24"		"\n" /*0x39 - TIMSK*/

	/*"pop    r24"            "\n"*/
	/*"out    __SREG__,r24"   "\n"*/ /*восстанавливаем SREG*/
	"pop    r24"            "\n" /*восстанавливаем r24*/ /*2 такта*/
	"reti"                  "\n" /*4 такта*/
	: /*Список выходных операндов*/
	: /*Список входных операндов*/
	);
}

//0x3F - __SREG__ 	Status register
//0x2F - TCCR1A
//0x2E - TCCR1B
//0x38 - TIFR
//0x39 - TIMSK
//0x12 - PORTD

//LDI Rd, K - Load Immediate. Rd <- k. Flags: None
//LDS Rd, k - Load Direct from SRAM. Rd <- (k). Flags: None
//SBI P,b - Set Bit in I/O Register.   I/O(P,b) <- 1. Flags: None
//CBI P,b - Clear Bit in I/O Register. I/O(P,b) <- 0. Flags: None
//EOR Rd, Rr - Exclusive OR Registers (XOR). Flags: Z, N, V
//eor	r1, r1 //r1=0
//RETI - Interrupt Return. Flags: I

//------------------------------------------------------------------------------
//volatile unsigned char buf[AMOUNT_NUM+2]; // размер буффера =AMOUNT_NUM+2: +точка,+конец строки
// номер элемента массива: 0...AMOUNT_NUM+1
#define buf lcd_buf
#define AMOUNT_NUM 5 // Число разрядов числа (размер буффера =AMOUNT_NUM+2: +точка,+конец строки )
//************************************************************************
// преобразует 16-bit 4-х разрядное число, записывает его в буфер индикатора       
// value - число для преобразования, comma = 0...3 - позиция точки на индикаторе(слева направо) 0...AMOUNT_NUM-1, 
//                                   comma >=    5 -  без точки  (AMOUNT_NUM+1)
// (comma = количество символов до точки)
void Uint_to_str (unsigned int value, unsigned char comma)
{
  signed char i; // номер элемента массива: 0...AMOUNT_NUM+1
  i = AMOUNT_NUM+1;
  buf[i]=0;      // конец строки
  while (i>0) {
    i--;
    if (i==comma) buf[i]='.'; // ставим точку
	else {
      buf[i] = '0'+ value%10;
      value = value/10;
	}
  }
    
}

//------------------------------------------------------------------------------
//Проверка Dead time
//Если T1_OCR2=0 ШИМ=0%
//Если T1_OCR2=T1_TOP ШИМ=100%
inline void DT_check (void)
{
	//ШИМ > 50 % недопустим
	//if (T1_OCR2>T1_TOP/2) T1_OCR2=T1_TOP/2;          //Dead time 0...1 такт F_CPU
	if (T1_OCR2>(T1_TOP-1)/2) T1_OCR2=(T1_TOP-1)/2;//Dead time 1...2 такта F_CPU
	//if (T1_OCR2>(T1_TOP/2)-1) T1_OCR2=(T1_TOP/2)-1;//Dead time 2...3 такта F_CPU
	
	T1_OCR1=T1_TOP-T1_OCR2;
}

//------------------------------------------------------------------------------
//Преобразование периода в частоту
uint32_t conv_period_freq (void)
{
	uint32_t value;
	value=(uint32_t)( (F_CPU+((uint32_t)T1_TOP*T1_div)/2 )/((uint32_t)T1_TOP*T1_div) );
	
	T1_OCR2=(uint16_t)( (((uint32_t)T1_TOP)*PWM+(uint32_t)10000/2)/10000 );// Длительность импульса
	if (T1_OCR2==0) T1_OCR2++;	 //Если T1_OCR2=0 ШИМ=0%
	DT_check();//Проверка Dead time
	T1_OCR1=T1_TOP-T1_OCR2;//длительность ШИМ1 (инверсный режим) (16-bit)
	
	return value;
}

//Преобразование ton в PWM Duty (коэффициент заполнения)
uint16_t conv_ton_PWM (void)
{
	uint16_t value;
	value=(uint16_t)( (10000UL*((uint32_t)T1_OCR2)+((uint32_t)T1_TOP)/2 )/((uint32_t)T1_TOP) );
	return value;
}

//------------------------------------------------------------------------------
//Расчет регистров 16-bit таймера 1 на основе частоты и коэффициента заполнения ШИМ
void T1_reg_calc (void)
{
	// Делитель таймера T1:
	T1_div=2; //F_T1= F_CPU
	TCCR1B_tmp=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(0<<CS11)|(1<<CS10); // F_T1= F_CPU/1 (Phase and Frequency Correct PWM)
	
	if (Freq<FREQ_MIN_D1) {
		T1_div=16;
		TCCR1B_tmp=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(1<<CS11)|(0<<CS10); // F_T1= F_CPU/8
	}
	if (Freq<FREQ_MIN_D8) {
		T1_div=128;
		TCCR1B_tmp=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(1<<CS11)|(1<<CS10); // F_T1= F_CPU/64
	}

	if (Freq<FREQ_MIN_D64) {
		T1_div=512;
		TCCR1B_tmp=(1<<WGM13)|(0<<WGM12)|(1<<CS12)|(0<<CS11)|(0<<CS10); // F_T1= F_CPU/256
	}

	// Расчет значений регистров Таймера 1
	T1_TOP=(uint16_t)( (F_CPU+ ((uint32_t)Freq*T1_div)/2 )/((uint32_t)Freq*T1_div) ); // Период импульса ( T=2*TOP*T1_div )
	T1_OCR2=(uint16_t)( (((uint32_t)T1_TOP)*PWM+(uint32_t)10000/2)/10000 );// Длительность импульса
	if (T1_OCR2==0) T1_OCR2++;	 //Если T1_OCR2=0 ШИМ=0%
	DT_check();//Проверка Dead time
	
	//Тест:
	// T1_TOP=1000;
	// T1_OCR2=990;
	
	// Уточнение частоты:
	if (Freq>FREQ_MAX_DF1Hz) Freq=conv_period_freq();//Преобразование периода в частоту
}

//------------------------------------------------------------------------------
//функция опроса энкодера
//Проверка состояния кнопок
void PollEncoder(void)
{
	static unsigned char stateEncFreq; 	//хранит последовательность состояний энкодера
	static unsigned char stateEncDuty;
	unsigned char tmp;
	unsigned char currentState;
	
	uint8_t BTN_state_tmp;
	uint8_t i;
	
	//Проверка состояния кнопок
	//#define THRES (0.7*BTN_DELAY) //(threshold) - порог срабатывания
	#define THRES (BTN_DELAY) //(threshold) - порог срабатывания
	
	//Накладываем маску на состояние кнопок и энкодера
	//Cостояние вращения энкодера не трогаем т.к. биты сбрасываются в main
	BTN_state_tmp = BTN_state & (BTN_st_FreqM | BTN_st_FreqP | BTN_st_DutyM | BTN_st_DutyP);
	i=0;//1-я кнопка
	if (Button_Mode)
	{
		ArrayBtnState[i]++;
		if (ArrayBtnState[i]>THRES) ArrayBtnState[i]=THRES;
		if (ArrayBtnState[i]>=THRES) BTN_state_tmp |= BTN_st_Mode;
	}
	else
	{
		if (ArrayBtnState[i]>0) ArrayBtnState[i]--;
		if (ArrayBtnState[i]==0) BTN_state_tmp &= ~BTN_st_Mode;
	}
	
	i++;//следующяя кнопка
	if (Enc_FreqS)
	{
		ArrayBtnState[i]++;
		if (ArrayBtnState[i]>THRES) ArrayBtnState[i]=THRES;
		if (ArrayBtnState[i]>=THRES) BTN_state_tmp |= BTN_st_FreqS;
	}
	else
	{
		if (ArrayBtnState[i]>0) ArrayBtnState[i]--;
		if (ArrayBtnState[i]==0) BTN_state_tmp &= ~BTN_st_FreqS;
	}

	i++;//следующяя кнопка
	if (Enc_DutyS)
	{
		ArrayBtnState[i]++;
		if (ArrayBtnState[i]>THRES) ArrayBtnState[i]=THRES;
		if (ArrayBtnState[i]>=THRES) BTN_state_tmp |= BTN_st_DutyS;
	}
	else
	{
		if (ArrayBtnState[i]>0) ArrayBtnState[i]--;
		if (ArrayBtnState[i]==0) BTN_state_tmp &= ~BTN_st_DutyS;
	}


	//проверяем состояние выводов энкодера Freq
	currentState = 0;
	if (Enc_FreqA) {SetBit(currentState,0);}
	if (Enc_FreqB) {SetBit(currentState,1);}

	//если равно предыдущему, то выходим
	tmp = stateEncFreq;
	if (currentState != (tmp & 0b00000011))
	{
		//если не равно, то сдвигаем и сохраняем в озу
		tmp = (tmp<<2)|currentState;
		//сравниваем получившуюся последовательность
		if		(tmp == 0b11100001) BTN_state_tmp |= BTN_st_FreqP;
		else if (tmp == 0b11010010) BTN_state_tmp |= BTN_st_FreqM;
		stateEncFreq = tmp;
	}
	
	//проверяем состояние выводов энкодера Duty
	currentState = 0;
	if (Enc_DutyA) {SetBit(currentState,0);}
	if (Enc_DutyB) {SetBit(currentState,1);}

	//если равно предыдущему, то выходим
	tmp = stateEncDuty;
	if (currentState != (tmp & 0b00000011))
	{
		//если не равно, то сдвигаем и сохраняем в озу
		tmp = (tmp<<2)|currentState;
		//сравниваем получившуюся последовательность
		if		(tmp == 0b11100001)	BTN_state_tmp |= BTN_st_DutyP;
		else if (tmp == 0b11010010) BTN_state_tmp |= BTN_st_DutyM;
		stateEncDuty = tmp;
	}

	BTN_state = BTN_state_tmp;
}

//------------------------------------------------------------------------------
//Реакция на кнопки и энкодер
inline void button_work(void)
{
	uint16_t step, dFreq, Freq_tmp;
	
	//Дискретность частоты dFreq , Гц (округление до ближайшего меньшего)
	if (Freq<0xFFFF) dFreq=(uint16_t)((Freq*Freq)/(F_CPU/2));
	else if (Freq<FREQ_MAX_DF1kHz)
	//Защита от переполнения 32-bit:
	{
		Freq_tmp=(uint16_t)(Freq/64);
		//#define F_CPU_tmp ((uint16_t)(F_CPU/(2*64*64)))
		dFreq=(uint16_t)(((uint32_t)Freq_tmp*Freq_tmp)/F_CPU_tmp);
	}
	else dFreq=0xFFFF;
		
	//step=1; // Шаг
	//F_step_sel - выбор шага частоты 1/10/100/1000 Гц
	if (F_step_sel == 0) step=1;
	if (F_step_sel == 1) step=10;
	if (F_step_sel == 2) step=100;
	if (F_step_sel == 3) step=1000;

	//Запрет прерывания таймера 1, для атомарного доступа к T1_TOP, T1_OCR2
	//если частота или коэф. заполнения меняются
	if (BTN_state & (BTN_st_FreqM | BTN_st_FreqP | BTN_st_DutyM | BTN_st_DutyP))
	{
		TIMSK = (0<<TICIE1)|(0<<TOIE1);
		TIFR=(1<<ICF1)|(1<<TOV1); //Очищаем флаги предыдущих не выполненных прерываний
	}

	// Кнопка Freq-
	if (BTN_state== BTN_st_FreqM)
	{
		//Если текущий шаг невозможен изменяем период на 1 такт CPU
		if (dFreq>=step)
		{
			//На низких частотах сюда не попадаем, поэтому делитель Timer1 не изменяем
			//Ограничение на максимальный период
			if (T1_TOP<0xFFFF) T1_TOP++;
			Freq=conv_period_freq();//Преобразование периода в частоту
		}
		else
		{
			if (Freq>(FREQ_MIN+step)) Freq-=step;
			else Freq=FREQ_MIN;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
	}

	// Кнопка Freq+
	if (BTN_state== BTN_st_FreqP)
	{
		//Если текущий шаг невозможен изменяем период на 1 такт CPU
		if (dFreq>=step)
		{
			//Ограничение на минимальный период
			if (T1_TOP>T_MIN) T1_TOP--;
			Freq=conv_period_freq();//Преобразование периода в частоту
		}
		else
		{
			Freq+=step;
			if (Freq>FREQ_MAX) Freq=FREQ_MAX;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
	}
	//--------------------------------------------------------------------
	//step=1; // Шаг
	//D_step_sel - выбор шага ШИМ 0,01/ 0,1 / 1 / 5 %
	if (D_step_sel == 0) step=1;
	if (D_step_sel == 1) step=10;
	if (D_step_sel == 2) step=100;
	if (D_step_sel == 3) step=500;

	// Кнопка Duty-
	if (BTN_state== BTN_st_DutyM)
	{
		//Если шаг больше 1 такта
		if ( ((((uint32_t)T1_TOP)*step)/10000) > 1)
		{
			if (PWM>(PWM_MIN+step)) PWM-=step;
			else PWM=PWM_MIN;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
		else if (T1_OCR2>1)
		{
			T1_OCR2--;
			DT_check();//Проверка Dead time
			PWM= conv_ton_PWM();//Преобразование ton в PWM (коэффициент заполнения)
		}
	}

	// Кнопка Duty+
	if (BTN_state== BTN_st_DutyP)
	{
		//Если шаг больше 1 такта
		if ( ((((uint32_t)T1_TOP)*step)/10000) > 1)
		{
			PWM+=step;
			if (PWM>PWM_MAX) PWM=PWM_MAX;
			T1_reg_calc();//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
		}
		else if (T1_OCR2<0xFFFF)
		{
			T1_OCR2++;
			DT_check();//Проверка Dead time
			PWM= conv_ton_PWM();//Преобразование ton в PWM (коэффициент заполнения)
		}
	}
		
	//--------------------------------------------------------------------
	//Кнопка энкодера Freq
	//F_step_sel - выбор шага частоты 1/10/100/1000 Гц
	if ((BTN_state == BTN_st_FreqS) && (BTN_state_prev != BTN_state))
	{
		F_step_sel++;
		if (F_step_sel > 3) 
		{
			F_step_sel = 0;
			if (dFreq>  9) F_step_sel++;
			if (dFreq> 99) F_step_sel++;
			if (dFreq>999) F_step_sel++;
		}
		blink_cycles = SYM_BLINK_CYCLES; //включаем мигание символа LCD
		blink_Duty = 0; //мигает частота Freq
	}

	//--------------------------------------------------------------------
	//Кнопка энкодера Duty
	//D_step_sel - выбор шага ШИМ 0,01/ 0,1 / 1 / 5 %
	if ((BTN_state == BTN_st_DutyS) && (BTN_state_prev != BTN_state))
	{
		D_step_sel++;
		if (D_step_sel > 3)
		{
			D_step_sel = 0;
			if (T1_TOP<999) D_step_sel = 1;//Если период меньше 1000 тактов, то дискретность ШИМ больше 0,1%
			if (T1_TOP< 99) D_step_sel = 2;//Если период меньше 100 тактов, то дискретность ШИМ больше 1%
		}
		blink_cycles = SYM_BLINK_CYCLES; //включаем мигание символа LCD
		blink_Duty = 1; //мигает коэф. заполнения Duty
	}

	//--------------------------------------------------------------------
	// Кнопка Mode.
	if ((BTN_state == BTN_st_Mode) && (BTN_state_prev != BTN_state))
	{
		mode++;
		if (mode>1) mode=0;
		if (mode==0) Output_Enable=1; else Output_Enable=0;
	}
	//--------------------------------------------------------------------
	BTN_state_prev=BTN_state;//Сохраняем текущее состояние кнопок в предыдущее 
	//--------------------------------------------------------------------
	//Если частота или коэф. заполнения меняются
	if (BTN_state & (BTN_st_FreqM | BTN_st_FreqP | BTN_st_DutyM | BTN_st_DutyP))
	{
		//Обновление параметров таймера T1
		
		//Если меняется коэффициент заполнения ШИМ 
		//Глитч: однократная несимметрия длительности ШИМ1 и ШИМ2
		if (BTN_state & (BTN_st_DutyM | BTN_st_DutyP))
		{
			OCR1A=T1_OCR1;	//длительность ШИМ1 (инверсный режим) (16-bit)
			OCR1B=T1_OCR2;	//длительность ШИМ2 (16-bit)
		}
		//Если частота меняется
		else //if (BTN_state & (BTN_st_FreqM | BTN_st_FreqP))
		{
			//Если период < 32 тактов и делитель не меняется и =2 (Freq >= 250 кГц)
			if ((T1_TOP<32) && (TCCR1B==TCCR1B_tmp) && (T1_div == 2))
			{
				//Частота уменьшается
				//Глитч: однократная несимметрия длительности ШИМ1 и ШИМ2
				//Глитч: однократное укорачивание длительности ШИМ1 и/или ШИМ2 (значения с предыдущего расчета)
				//ICR1 =T1_TOP; // период ШИМ (16-bit) (порядок записи важен)
				//OCR1A=T1_OCR1; // длительность ШИМ1 (16-bit)
				//OCR1B=T1_OCR2; // длительность ШИМ2 (16-bit)
				if (BTN_state== BTN_st_FreqM)
				{ asm volatile(
					"out	0x27, r11"		"\n" /*0x27 - ICR1H,  r11 - T1_TOP_H*/
					"out	0x26, r10"		"\n" /*0x26 - ICR1L,  r10 - T1_TOP_L*/
					/*"out	0x2b, r13"		"\n"*/ /*0x2B - OCR1AH, r13 - T1_OCR1_H*/
					"out	0x2a, r12"		"\n" /*0x2A - OCR1AL, r12 - T1_OCR1_L*/
					/*"out	0x29, r15"		"\n"*/ /*0x29 - OCR1BH, r15 - T1_OCR2_H*/
					"out	0x28, r14"		"\n" /*0x28 - OCR1BL, r14 - T1_OCR2_L*/
				::); }
				//Частота увеличивается
				//Глитч: однократная несимметрия длительности ШИМ1 и ШИМ2
				//Глитч: однократное удлинение периода ШИМ1 и/или ШИМ2 (значения с предыдущего расчета)
				//OCR1A=T1_OCR1; // длительность ШИМ1 (16-bit)
				//OCR1B=T1_OCR2; // длительность ШИМ2 (16-bit)
				//ICR1 =T1_TOP; // период ШИМ (16-bit) (порядок записи важен)
				if (BTN_state== BTN_st_FreqP)
				{ asm volatile(
					"ldi	r24, 0x01"		"\n" /*r24 = 0x01*/
					
					"out	0x2b, r13"		"\n" /*0x2B - OCR1AH, r13 - T1_OCR1_H*/
					"out	0x2a, r12"		"\n" /*0x2A - OCR1AL, r12 - T1_OCR1_L*/
					/*"out	0x29, r15"		"\n"*/ /*0x29 - OCR1BH, r15 - T1_OCR2_H*/
					"out	0x28, r14"		"\n" /*0x28 - OCR1BL, r14 - T1_OCR2_L*/
					
					/*"out	0x2d, r11"		"\n"*/ /*0x2D - TCNT1H = 0*/
					"out	0x2c, r24"		"\n" /*0x2C - TCNT1L = 1*/

					/*"out	0x27, r11"		"\n"*/ /*0x27 - ICR1H, r11 - T1_TOP_H*/
					"out	0x26, r10"		"\n" /*0x26 - ICR1L,  r10 - T1_TOP_L*/
				::); }
			}
			//Для теста закомментировать else, и оставить блок{} (прерывание выполнится даже на высокой частоте)
			else
			{
				cli();// Запрет прерываний
				//TICIE1 - Timer1 Input Capture Interrupt: On
				//TOIE1  - Timer1 Overflow Interrupt: Off
				TIMSK = (1<<TICIE1)|(0<<TOIE1); //TOIE1 устанавливается в прерывании TICIE1
				//ICF1 - Timer1, Input Capture Flag
				//TOV1 - Timer1, Overflow Flag
				TIFR=(1<<ICF1)|(1<<TOV1); //Очищаем флаги предыдущих не выполненных прерываний для синхронизации с началом периода
				sei();// Разрешение прерываний
				//1.Выполнение прерывания TICIE1 (1 раз для обновления OCR1A, OCR1B в начале периода)
				//2.Выполнение прерывания TOIE1  (1 раз для обновления делителя и ICR1 (TOP) в начале периода)
				//Если частота > 80 кГц
				//if (T1_TOP<100)
				{
					//Ждем выполнения 2-х прерываний, чтобы минимизировать задержку обновления
					while ( (TIMSK & ((1<<TICIE1)|(1<<TOIE1))) != 0) {};
				}
			}
		}
		
		//Сбрасываем флаги нажатия виртуальных кнопок энкодера
		BTN_state &= ~(BTN_st_FreqM | BTN_st_FreqP | BTN_st_DutyM | BTN_st_DutyP);
		save_delay = SAVE_DELAY; //перезапуск таймера записи в EEPROM
	}
	//Дополнительная задержка при удержании кнопки
	if (BTN_state != 0) no_action_delay = 200; //200 x 1,55 мс
}

//------------------------------------------------------------------------------
//void main(void) __attribute__((noreturn));
void main(void) __attribute__((OS_main));
void main(void)
{
	//Локальные переменные:
	//char *str_ptr;
	unsigned char i, diapazon;
	uint32_t indication;
	
	//-------------------------------------------------------------
	// Port B initialization
	// Выключаем подтяжку на цифровых входах
	PORTB=(0<<b5)|(0<<b4)|(0<<b3)|(0<<b2)|(0<<b1)|(0<<b0);
	DDRB= (1<<b5)|(1<<b4)|(1<<b3)|(1<<b2)|(1<<b1)|(0<<b0);//Выходы-"1", Входы-"0"

	// Port C initialization
	// Выключаем подтяжку на цифровых входах 0...5
	// PORTC.6 - RESET
	// PORTC.0-3 : ADC0-3
	// PORTC.4 - I2C SDA
	// PORTC.5 - I2C SCL
	//PORTC=(1<<b6)|(1<<b5)|(1<<b4)|(1<<b3)|(1<<b2)|(1<<b1)|(1<<b0);
	PORTC=(1<<b6) ;//0...5 - без подтяжки
	DDRC=        (0<<b5)|(0<<b4)|(0<<b3)|(0<<b2)|(0<<b1)|(0<<b0);//Все входы (Выходы-"1", Входы-"0")

	// Port D initialization
	PORTD=(0<<b7)|(0<<b6)|(0<<b5)|(0<<b4)|(0<<b3)|(0<<b2)|(0<<b1)|(0<<b0);
	DDRD= (1<<b7)|(1<<b6)|(1<<b5)|(1<<b4)|(1<<b3)|(1<<b2)|(1<<b1)|(1<<b0);//Все выходы

	// Timer/Counter 0 initialization

	// 16 bit Timer/Counter 1 initialization
	// Clock source: System Clock,
	// Prescaler for Timer/Counter1: stop  /1  /8  /64  /256 /1024
	// Mode: Fast PWM, TOP=ICR1
	// OC1A output: Disconnected (COM1A1, COM1A0)
	// OC1B output: Disconnected (COM1B1, COM1B0)
	// Timer1 Input Capture Interrupt (TICIE1): Off
	// Timer1 Output Compare A Match Interrupt (TICIE1): Off
	// Timer1 Output Compare B Match Interrupt (OCIE1B): Off
	// Timer1 Overflow Interrupt (TOIE1): Off
	//No clock source. (Timer/Counter stopped) CS12, CS11, CS10
	TCCR1A=(0<<COM1A1)|(0<<COM1A0)|(0<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	TCCR1B=(1<<WGM13)|(0<<WGM12)|(0<<CS12)|(0<<CS11)|(0<<CS10);
	
	//TCNT1=0x0000; //обнуляем 16-bit счетный регистр таймера/счетчика Т1
	// ICR1=(uint16_t)( F_CPU/((uint32_t)FREQ_DEF) )-1; // Период импульса - 1
	// OCR1B=(uint16_t)( F_CPU*(uint32_t)PWM_DEF/((uint32_t)FREQ_DEF*10000) )-1;// Длительность импульса - 1
	//SFIOR=(1<<PSR10);//Сброс предделителя таймера 0 и таймера 1

	// 8 bit Timer/Counter 2 initialization

	// Timer(s)/Counter(s) Interrupt(s) initialization
	//TICIE1 - Timer1 Input Capture Interrupt: Off
	//TOIE1  - Timer1 Overflow Interrupt: Off
	//TIMSK = (0<<TICIE1)|(0<<TOIE1); 

	// External Interrupt(s) initialization
	// INT0: Off
	// INT1: Off
	//MCUCR=0x00;

	// USART initialization
	// USART disabled
	//UCSRB=0x00;

	// Analog Comparator initialization
	// Analog Comparator: Off
	// Analog Comparator Input Capture by Timer/Counter 1: Off
	//ACSR=0x80;
	//SFIOR=0x00;

	// ADC initialization
	// ADC Free running mode disabled (однократный режим)
	// ADC Prescaler                             /2  /4  /8 /16 /32 /64 /128
	// ADC Prescaler Selections       ADPS[2:0] 001,010,011,100,101,110, 111
	// ADC Clock frequency: F_ADC=125 kHz, F_CPU          1   2   4   8   16 MHz
	// Internal 2.56V reference, cap. on AREF. Правое выравнивание результата

	// SPI initialization
	// SPI disabled
	//SPCR=0x00;
		
	// TWI initialization
	// TWI disabled
	//TWCR=0x00;

	LCD_Init(); // Инициализация портов и ЖК индикатора
	//Значения по умолчанию:
	mode=0;
	Output_Enable=1;
	BTN_state_prev=0;

	//Чтение из EEPROM
	Freq = eeprom_read_dword (&E_Freq);
	PWM = eeprom_read_word (&E_PWM);
	if ((Freq<FREQ_MIN)||(Freq>FREQ_MAX)) Freq=FREQ_DEF;
	if (PWM>PWM_MAX) PWM=PWM_DEF;
	//Расчет регистров 16 бит таймера 1 на основе частоты и коэффициента заполнения ШИМ
	T1_reg_calc();
	
	ICR1= T1_TOP; // период ШИМ (16-bit)
	OCR1A=T1_OCR1;	//длительность ШИМ1 (инверсный режим) (16-bit)
	OCR1B=T1_OCR2;	//длительность ШИМ2 (16-bit)
	//TCNT1=0x0000; //обнуляем 16-bit счетный регистр таймера Т1
	SFIOR=(1<<PSR10);//Сброс предделителя таймера 0 и таймера 1
	// Mode: Fast PWM, TOP=ICR1
	// OC1A output: Disconnected (COM1A1, COM1A0)
	// OC1B output: Clear OC1B on Compare Match, set OC1B at BOTTOM (non-inverting mode) (COM1B1, COM1B0)
	TCCR1A=(1<<COM1A1)|(1<<COM1A0)|(1<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	TCCR1B=TCCR1B_tmp; //Устанавливаем делитель Таймера 1 (запускаем таймер)
		
	wdt_enable(WDTO_500MS); // Разрешение работы сторожевого таймера с тайм-аутом 500 мс
	sei();// Разрешение прерываний
	
	F_step_sel = 0;  //шаг 1 Гц
	D_step_sel = 2; //шаг 1 %
	//счетчик задержки на запись в EEPROM
	//0 - запись запрещена
	//1 - запись разрещена
	//>1 - ожидание записи 
	save_delay = 0;
  while (1){			
	//---------------------------------------------------------------------------------------------
	//SetBitVal(PORTD,1, 1); //Тест
	wdt_reset();  // Сброс сторожевого таймера
	PollEncoder();//Опрос энкодера и кнопок

	//Вывод на LCD - около 1,50 мс / 1,55 мс while (1)
	//формат вывода частоты:
	//01234567
	//    999
	//  1.000k
	// 10.000k
	//999.999k
	//1.60000M
	
	//формат вывода коэффициента заполнения:
	//01234567
	//000.00 %
	//015.93 %
	//100.00 %

	indication=Freq; //частота
	diapazon='k';//Килогерцы
	if (indication<1000)
	{
		diapazon=' ';//Герцы
	}
	else if (indication>=1000000)
	{
		indication=(indication+5)/10; //деление с округлением
		diapazon='M';//Мегагерцы
	}
	
	i=6;//Последний символ числа
	lcd_buf[i--]='0'+indication%10;// 0x30 - код символа '0'
	indication=indication/10;
	lcd_buf[i--]='0'+indication%10;
	indication=indication/10;
	lcd_buf[i--]='0'+indication%10;
	if (diapazon==' ')
	{
		lcd_buf[i--]=' ';
		lcd_buf[i--]=' ';
		lcd_buf[i--]=' ';
		lcd_buf[i--]=' ';
	}
	else
	{
		if (diapazon=='k') lcd_buf[i--]='.';
		indication=indication/10;
		lcd_buf[i--]='0'+indication%10;
		indication=indication/10;
		lcd_buf[i--]='0'+indication%10;
		indication=indication/10;
		if (diapazon=='M') lcd_buf[i--]='.';
		lcd_buf[i]='0'+indication%10;
	}
	//Отбрасываем 1..2 ведущих нуля
	if (diapazon==' ') i=4;
	if (lcd_buf[i]=='0')
	{
		lcd_buf[i++]=' ';
		if (lcd_buf[i]=='0') lcd_buf[i++]=' ';
	}
	i = 7;
	lcd_buf[i++]=diapazon;
	lcd_buf[i++]='H';
	lcd_buf[i++]='z';
	lcd_buf[i]=0; //конец строки LCD WH1602
	//lcd_buf[8]=0; //конец строки LCD WH0802
	
	//Перезапуск таймера полупериода
	if (blink_period == 0) blink_period = SYM_BLINK_PERIOD;

	//Если мигание разрешено
	if ((blink_cycles > 0) && (blink_Duty == 0))
	{
		//F_step_sel - выбор шага частоты 1/10/100/1000 Гц
		if (F_step_sel == 0) i=6;
		if (F_step_sel == 1) i=5;
		if (F_step_sel == 2) i=4;
		if (F_step_sel == 3) i=2;
		//На четных полупериодах гасим символ
		if ((blink_cycles & 0x01) == 0)
		{
			if (lcd_buf[i] != ' ') lcd_buf[i] =' ';//пробел
			else lcd_buf[i] = 0xFF;//Черный пробел
		}
	}
	LCD_Goto(0, 0); // Переводим курсор на первый символ первой строки
	LCD_SendString(lcd_buf);   // Выводим на дисплей LCD
	
	//SetBitVal(PORTD,1, 0); //Тест
	PollEncoder();//Опрос энкодера и кнопок

	//conv_ton_PWM() - Уточнение коэффициента заполнения
	if (Output_Enable==1)
	{
		Uint_to_str (conv_ton_PWM(),3); // Преобразование числа в строку
	}
	else Uint_to_str (0,3); //Если выход выкл. то выводим 0 %
	
	i = 6;
	lcd_buf[i++]=' ';
	lcd_buf[i++]='%';
	lcd_buf[i]=0; //конец строки
	//Отбрасываем 1..2 ведущих нуля
	i=0;
	if (lcd_buf[i]=='0')
	{
		lcd_buf[i++]=' ';
		if (lcd_buf[i]=='0') lcd_buf[i++]=' ';
	}
	
	//Если мигание разрешено
	if ((blink_cycles > 0) && (blink_Duty == 1))
	{
		//D_step_sel - выбор шага ШИМ 0,01/ 0,1 / 1 / 5 %
		if (D_step_sel == 0) i = 5;
		if (D_step_sel == 1) i = 4;
		if (D_step_sel == 2) i = 2;
		if (D_step_sel == 3) i = 2;
		//На четных полупериодах гасим символ
		if ((blink_cycles & 0x01) == 0)
		{
			if (lcd_buf[i] != ' ') lcd_buf[i] =' ';//пробел
			else lcd_buf[i] = 0xFF;//Черный пробел
		}
	}
	LCD_Goto(0, 1); // Переводим курсор на первый символ второй строки
	LCD_SendString(lcd_buf);   // Выводим на дисплей LCD
	
	if (blink_cycles > 0)
	{
		if (blink_period > 0) blink_period--;
		//Если время полупериода прошло уменьшаем число полупериодов
		if (blink_period == 0) blink_cycles--;
	}
	
	//SetBitVal(PORTB,1, 0); //Тест
	
	//------------------------------------------------------------------------------
	//Пауза на отсутсвие реакции на кнопки
	//(быстрая реакция на первое нажатие кнопки и замедленная реакция на удержание кнопки)
	if (no_action_delay > 0) no_action_delay--;
	//Ждем окончания паузы и чтобы делитель (TCCR1B) обновился в прерывании
	if ( (no_action_delay == 0) && ((TIMSK & ((1<<TICIE1)|(1<<TOIE1))) == 0) ) button_work();

	//Вкл/выкл выхода (Phase and Frequency Correct PWM)
	if (Output_Enable==1)
	{
		// OC1A output: 
		//Set OC1A on Compare Match when up-counting. Clear OC1A on Compare Match when downcounting.
		//(inverting mode) (COM1A1, COM1A0)
		// OC1B output: 
		//Clear OC1B on Compare Match when up-counting. Set OC1B on Compare Match when downcounting. 
		//(non-inverting mode) (COM1B1, COM1B0)
		TCCR1A=(1<<COM1A1)|(1<<COM1A0)|(1<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	}
	else
	{
		// OC1A output: Disconnected (COM1A1=0, COM1A0=0)
		// OC1B output: Disconnected (COM1B1=0, COM1B0=0)
		TCCR1A=(0<<COM1A1)|(0<<COM1A0)|(0<<COM1B1)|(0<<COM1B0)|(0<<WGM11)|(0<<WGM10);
	}
	//--------------------------------------------------------------------
	//счетчик задержки на запись в EEPROM
	//0 - запись запрещена
	//1 - запись разрещена
	//>1 - ожидание записи
	if (save_delay > 1) save_delay--;

	//Ожидание разрешения на запись в EEPROM
	if (save_delay == 1)
	{
		//запись в EEPROM 8,32 мс
		SetBitVal(PORTD,1, 0); //Тест	
		save_delay = 0; //сбрасываем флаг разрешения
		eeprom_update_dword ((uint32_t*)&E_Freq, Freq);
		eeprom_update_word ((uint16_t*)&E_PWM, PWM);
	}
	
 }// while (1)

} // main
