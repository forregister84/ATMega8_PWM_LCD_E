#ifndef BITS_MACROS_
#define BITS_MACROS_
/***********************************************************
//BITS MACROS
//PASHGAN 2009
//CHIPENABLE.RU
//
//reg : им¤ переменной, регистра
//bit : позици¤ бита
//val : 0 или 1
************************************************************/
#define bit0 0
#define bit1 1
#define bit2 2
#define bit3 3
#define bit4 4
#define bit5 5
#define bit6 6
#define bit7 7

#define b0 0
#define b1 1
#define b2 2
#define b3 3
#define b4 4
#define b5 5
#define b6 6
#define b7 7

#define Bit(bit)  (1<<(bit))

//«апись битов
#define ClearBit(reg, bit)       reg &= (~(1<<(bit)))
//пример: ClearBit(PORTB, 1); //сбросить 1-й бит PORTB

#define SetBit(reg, bit)          reg |= (1<<(bit))
//пример: SetBit(PORTB, 3); //установить 3-й бит PORTB

#define SetBitVal(reg, bit, val) do{if ((val&1)==0) reg &= (~(1<<(bit)));\
                                  else reg |= (1<<(bit));}while(0)
//пример: SetBitVal(PORTB, 3, 1); //установить 3-й бит PORTB
//	  SetBitVal(PORTB, 2, 0); //сбросить 2-й бит PORTB

#define InvBit(reg, bit)	  reg ^= (1<<(bit))
//пример: InvBit(PORTB, 1); //инвертировать 1-й бит PORTB

//ѕроверка битов
#define BitIsClear(reg, bit)    ((reg & (1<<(bit))) == 0)
//пример: if (BitIsClear(PINB,1)) {...} //если бит очищен
//пример: if (BitIsClear(data,1)) {...} //если бит очищен

#define BitIsSet(reg, bit)       ((reg & (1<<(bit))) != 0)
//пример: if(BitIsSet(PINB,2)) {...} //если бит установлен
//пример: if(BitIsSet(data,2)) {...} //если бит установлен

#endif//BITS_MACROS_



